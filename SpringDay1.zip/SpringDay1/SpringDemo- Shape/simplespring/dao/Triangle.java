package com.htc.simplespring.dao;

public class Triangle implements Shape {
	private String msg;
	private int height;
	
	

	public Triangle(int height) {
		super();
		this.height = height;
	}


	public Triangle(String msg) {
		super();
		this.msg = msg;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


	@Override
	public void draw() {
	
		System.out.println("Draw Triangle " +"with hieght " +this.height);
		
	}

	
}
