package com.htc.simplespring.dao;

public interface Shape {

	public void draw();
}
