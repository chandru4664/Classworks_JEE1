package com.htc.jaxws.rpc;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class HelloWorldWSClient {
	public static void main(String args[]) {
		try {
			URL url = new URL("http://localhost:7070/ws/helloWorldRCP?wsdl");
			QName qname = new QName("http://rpc.jaxws.htc.com/", "HelloWorldService");
			
			Service service = Service.create(url, qname);
			
			IHelloWorld helloWorld = service.getPort(IHelloWorld.class);
			String response=helloWorld.sayHello("Gopi");
			System.out.println("SOAP response:"+response);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
}
