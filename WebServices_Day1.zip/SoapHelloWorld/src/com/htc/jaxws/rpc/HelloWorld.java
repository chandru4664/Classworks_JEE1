package com.htc.jaxws.rpc;

import javax.jws.WebService;

/**
 * Service Endpoint Implementation
 * 
 */
@WebService(endpointInterface = "com.htc.jaxws.rpc.IHelloWorld")
public class HelloWorld implements IHelloWorld {
	@Override
	public String sayHello(String name) {
		return "JAX-WS RCP Style. Hello " + name;
	}
}
