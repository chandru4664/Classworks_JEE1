package com.htc.bankapp.dao;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import com.htc.bankapp.dto.Bank;
import com.htc.bankapp.dto.BankAccount;
import com.htc.bankapp.exceptions.InvalidAccountNumberException;
@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public interface BankOperations {

	@WebMethod
	public void setBank(Bank bank);
	@WebMethod	
	public BankAccount getAccount(String accountNo)throws InvalidAccountNumberException;
	@WebMethod
	public double getBalance(String accountNo)throws InvalidAccountNumberException ;
	@WebMethod
	public boolean withdraw(String accountNo,double amount)throws InvalidAccountNumberException ;
	@WebMethod
	public boolean deposit(String accountNo, double amount)throws InvalidAccountNumberException ;
	@WebMethod
	public boolean transfer(String fromAccountNo,String toAccountNo,double amount)throws InvalidAccountNumberException ;
	
	
}
