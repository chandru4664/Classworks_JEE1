package com.htc.bankapp.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.htc.bankapp.dao.BankOperations;
import com.htc.bankapp.dto.Bank;
import com.htc.bankapp.dto.BankAccount;
import com.htc.bankapp.exceptions.InvalidAccountNumberException;

public class SoapClient {

	public static void main(String[] args) throws MalformedURLException {
		
		URL wsdlURL= new URL("http://localhost:12345/ws/bank?wsdl");
		
		QName qname=new QName("http://dao.bankapp.htc.com/","BankOperationsImplService");
		
		Service service = Service.create(wsdlURL, qname);
		
		
		BankOperations bankservice=service.getPort(BankOperations.class);
		
		
		Bank bank=new Bank();
		//BankAccount[] bankAccounts=new BankAccount[5];
		ArrayList<BankAccount> bankAccounts=new ArrayList<BankAccount>();
		
		
		
		bankAccounts.add(new BankAccount("12345","Gopi"));
		bankAccounts.add(new BankAccount("1234567","John"));;
		bankAccounts.add(new BankAccount("123456","Dev"));
		
		
		bank.setIFSI("ICIC0012");
		bank.setName("ICICI");
		bank.setBranch("Chennai");
		bank.setBankAccounts(bankAccounts);
		
		
		
		bankservice.setBank(bank);
		
		
		try {
			System.out.println("Deposit: "+bankservice.deposit("12345", 5100.00));
			System.out.println("New Balance: "+bankservice.getBalance("12345"));
		} catch (InvalidAccountNumberException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
