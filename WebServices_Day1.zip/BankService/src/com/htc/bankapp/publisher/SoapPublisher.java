package com.htc.bankapp.publisher;

import javax.xml.ws.Endpoint;

import com.htc.bankapp.dao.BankOperationsImpl;

public class SoapPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:12345/ws/bank", new BankOperationsImpl());
		System.out.println("Service started...");
	}

}
