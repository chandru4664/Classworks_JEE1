package com.htc.test.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.htc.test.beans.Trainer;

@Configuration
public class TrainerConfig {
	
	@Bean(name="trainer")
	public Trainer setTrainer() {
		Trainer trainer=new Trainer();
		trainer.setName("Charles");
		trainer.setTrainerID(12324);
		return trainer;
	}

}
