package com.htc.test.beans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("trainer")
public class Trainer {
	
	@Value(value="111")
	private int trainerID;
	@Value(value="John")
	private String name;
	
	
	public int getTrainerID() {
		return trainerID;
	}
	public void setTrainerID(int trainerID) {
		this.trainerID = trainerID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Trainer(int trainerID, String name) {
		super();
		this.trainerID = trainerID;
		this.name = name;
	}
	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Trainer [trainerID=" + trainerID + ", name=" + name + "]";
	}
	
	

}
