package com.htc.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainees")
public class Trainees implements Serializable{

	@Id
	@Column(name="traineeid")
	private int traineeID;
	
	@Column(name="name",nullable=false)
	private String traineeName;
	
	@Override
	public String toString() {
		return "Trainees [traineeID=" + traineeID + ", traineeName=" + traineeName + "]";
	}
	
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	
	public Trainees(int traineeID, String traineeName) {
		super();
		this.traineeID = traineeID;
		this.traineeName = traineeName;
	}
	public Trainees() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
