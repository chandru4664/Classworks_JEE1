package com.htc.main;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.htc.dto.Trainees;

public class Main {
	public static SessionFactory sessionFactory;
	
	static{
		// Configure Hibernate 5.2 
		Configuration config=new Configuration();
		//read config info from hibernate.cfg.xml
		config.configure();
		
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		builder.applySettings(config.getProperties());
		
		StandardServiceRegistry standardServiceRegistry=builder.build();
		
		MetadataSources metadataSources=new MetadataSources(standardServiceRegistry);
		metadataSources.addAnnotatedClass(Trainees.class);
		
		
		Metadata metadata=metadataSources.buildMetadata();
		sessionFactory=metadata.buildSessionFactory();
	}
	
	public static void main(String[] args) {
		
		Session session=sessionFactory.openSession();
		Transaction tran=session.getTransaction();
		
		try{
			tran.begin();
			session.save(new Trainees(100,"Darwin"));
			System.out.println("saved...");
			tran.commit();
		}
		catch(HibernateException ex) {
			tran.rollback();
			System.out.println(ex.getMessage());
		}
			
	}

}
