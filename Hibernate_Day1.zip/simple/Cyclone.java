package com.htc.hibernate.simple;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Cyclones")
public class Cyclone implements Serializable{

	@Id
	private int cycloneID;
	@Column(length=20)
	private String cycloneName;
	@Column
	private double speed;
	@Column(length=20)
	private String affectedLocation;
	@Column
	private double totalLoss;
	
	
	
	public Cyclone(int cycloneID, String cycloneName, double speed, String affectedLocation, double totalLoss) {
		super();
		this.cycloneID = cycloneID;
		this.cycloneName = cycloneName;
		this.speed = speed;
		this.affectedLocation = affectedLocation;
		this.totalLoss = totalLoss;
	}
	public double getTotalLoss() {
		return totalLoss;
	}
	public void setTotalLoss(double totalLoss) {
		this.totalLoss = totalLoss;
	}
	@Override
	public String toString() {
		return "Cyclone [cycloneID=" + cycloneID + ", cycloneName=" + cycloneName + ", speed=" + speed
				+ ", affectedLocation=" + affectedLocation + ", totalLoss=" + totalLoss + "]";
	}
	public Cyclone() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cyclone(int cycloneID, String cycloneName, double speed, String affectedLocation) {
		super();
		this.cycloneID = cycloneID;
		this.cycloneName = cycloneName;
		this.speed = speed;
		this.affectedLocation = affectedLocation;
	}
	public int getCycloneID() {
		return cycloneID;
	}
	public void setCycloneID(int cycloneID) {
		this.cycloneID = cycloneID;
	}
	public String getCycloneName() {
		return cycloneName;
	}
	public void setCycloneName(String cycloneName) {
		this.cycloneName = cycloneName;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public String getAffectedLocation() {
		return affectedLocation;
	}
	public void setAffectedLocation(String affectedLocation) {
		this.affectedLocation = affectedLocation;
	}
	
	
	
}
