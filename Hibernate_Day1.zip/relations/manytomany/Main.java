package com.htc.hibernate.relations.manytomany;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.text.SimpleAttributeSet;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class Main {

	static SessionFactory sf=null;
	static{
		Configuration cf=new Configuration();
		cf=cf.configure();
		cf.addAnnotatedClass(com.htc.hibernate.relations.manytomany.Employees.class);
		cf.addAnnotatedClass(com.htc.hibernate.relations.manytomany.Skills.class);
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		builder=builder.applySettings(cf.getProperties());
		ServiceRegistry registry=builder.build();
		sf=cf.buildSessionFactory(registry);
	}
	public static void main(String[] args) {
		
		SimpleDateFormat sdf=new SimpleDateFormat();
		Date joinDate=new Date();
		try {
			sdf.applyPattern("dd/MM/yyyy");
			joinDate=sdf.parse("11/02/2016");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Session session=sf.openSession();
		Transaction trans=session.getTransaction();
		trans.begin();
		try{
			Skills skill1=new Skills(11,"Mainframe");
			Skills skill2=new Skills(12,"Angular4");
			Skills skill3=new Skills(13,"PHP");
			session.save(skill1);
			session.save(skill2);
			session.save(skill3);
			
			//Employees emp1=new Employees(123,"Raja",joinDate,20000.00);
			Employees emp2=new Employees(126,"Charles",joinDate,25000.00);
			Employees emp3=new Employees(127,"Darwin",joinDate,30000.00);
			
			//session.save(emp1);
			session.save(emp2);
			session.save(emp3);
			
			//Adding skills to employee with empId=123
			Employees skilledEmp=(Employees)session.load(Employees.class,123);
			
			//skills (skillId=111,112) to be added to empId=123
			Skills empSkill=(Skills)session.load(Skills.class, 11);
			Skills empSkil2=(Skills)session.load(Skills.class, 12);
			
			//updating employees skills
			skilledEmp.getSkills().add(empSkill);
			skilledEmp.getSkills().add(empSkil2);
			
			session.update(skilledEmp);

			//Deleting an employee
			//session.delete((Employees)session.load(Employees.class,123));
			//Updating employee salary
			/*Employees emp=(Employees)session.load(Employees.class, 124);
			emp.setSalary(emp.getSalary()+25000.00);
			session.update(emp);*/
			//EntityManager.merge(emp); //in JPA
			trans.commit();
			
			System.out.println("Skills added to employee...");
		}catch(HibernateException he){
			he.printStackTrace();
			trans.rollback();
		}finally{
			session.close();
		}
		
	}
}
