package com.htc.hibernate.relations.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="mobile")
public class Mobile {

	@Id
	private int IMEI;
	@Column(length=30)
	private String manufacturer;
	@Column(length=30)
	private String model;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="keyBoardSerialNo")
	private Keyboard keyboard;
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int iMEI, String manufacturer, String model, Keyboard keyboard) {
		super();
		IMEI = iMEI;
		this.manufacturer = manufacturer;
		this.model = model;
		this.keyboard = keyboard;
	}
	@Override
	public String toString() {
		return "Mobile [IMEI=" + IMEI + ", manufacturer=" + manufacturer
				+ ", model=" + model + ", keyboard=" + keyboard + "]";
	}
	public int getIMEI() {
		return IMEI;
	}
	public void setIMEI(int iMEI) {
		IMEI = iMEI;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Keyboard getKeyboard() {
		return keyboard;
	}
	public void setKeyboard(Keyboard keyboard) {
		this.keyboard = keyboard;
	}
	
	
	
	
}
