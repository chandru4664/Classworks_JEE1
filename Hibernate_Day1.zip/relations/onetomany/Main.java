package com.htc.hibernate.relations.onetomany;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class Main {

	static SessionFactory sf=null;
	static{
		Configuration cf=new Configuration();
		cf=cf.configure();
		cf.addAnnotatedClass(com.htc.hibernate.relations.onetomany.Team.class);
		cf.addAnnotatedClass(com.htc.hibernate.relations.onetomany.Players.class);
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		builder=builder.applySettings(cf.getProperties());
		ServiceRegistry registry=builder.build();
		sf=cf.buildSessionFactory(registry);
	}
	public static void main(String[] args) {
		Session session=sf.openSession();
		Transaction trans=session.getTransaction();
		trans.begin();
		try{
			Players player1=new Players(10,"Sachin","Batsman");
			Players player2=new Players(18,"kohli","Captain");
			Players player3=new Players(7,"Dhoni","Keeper");
			
			session.save(player1);
			session.save(player2);
			session.save(player3);
			
			Team criketTeam=new Team();
			criketTeam.setTeamId(20);
			criketTeam.setTeamName("IndiaTeam");
			criketTeam.setTrainer("Dravid");
			
			criketTeam.getPlayers().add(player1);
			criketTeam.getPlayers().add(player2);
			criketTeam.getPlayers().add(player3);
			
			session.save(criketTeam);
			
			//session.delete((Team)session.load(Team.class,20));
			
			trans.commit();
			//System.out.println("player with id=7 has been removed");
			System.out.println("Criket Team created...");
		}catch(HibernateException he){
			he.printStackTrace();
			trans.rollback();
		}
		
	}
}
