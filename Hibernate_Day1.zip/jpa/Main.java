package com.htc.hibernate.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.HibernateException;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("persist");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		
		try{
			trans.begin();
			// insert
			manager.persist(new Cyclone(128,"Java",1000.00,"HTC",5000.00));
			System.out.println("Object saved..");
			
			// retrive
			Cyclone javaCyclone=manager.find(Cyclone.class, 128);
			System.out.println(javaCyclone.toString());
			trans.commit();
			
			
			
		}
		catch(HibernateException he){
			he.getMessage();
			trans.rollback();
		}
		finally{
			manager.close();
		}
	}
}
