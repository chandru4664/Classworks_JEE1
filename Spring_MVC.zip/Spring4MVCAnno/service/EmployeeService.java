package com.htc.spring4mvc.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.htc.spring4mvc.dao.EmployeeDAO;
import com.htc.spring4mvc.dto.DepartmentDTO;
import com.htc.spring4mvc.dto.EmployeeDTO;
import com.htc.spring4mvc.entity.Department;
import com.htc.spring4mvc.entity.Employee;

@Service("employeeService")
@Transactional(propagation=Propagation.REQUIRED, readOnly=true)
public class EmployeeService {

	public DepartmentDTO getDepartmentDTO(Department dept) {
		return new DepartmentDTO(dept.getDeptno(), dept.getDeptName());
	}
	
	public Department getDepartment(DepartmentDTO dept) {
		return new Department(dept.getDeptno(), dept.getDeptname());
	}

	public EmployeeDTO getEmployeeDTO(Employee emp) {
		return new EmployeeDTO(emp.getEmpno(), emp.getEmpname(),emp.getJob(), emp.getSalary(), emp.getDepartment().getDeptno());
	}
	
	public Employee getEmployee(EmployeeDTO emp) {
		return new Employee(emp.getEmpno(), emp.getEmpname(), emp.getSalary(), emp.getJob());
	}

	EmployeeDAO employeeDAO;
	@Autowired
	public EmployeeService(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public boolean addEmployee( Employee emp) {
		return employeeDAO.addEmployee(emp);
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public boolean addDepartment(DepartmentDTO dept) {
		
		return employeeDAO.addDepartment(getDepartment(dept));
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public  boolean addEmployeeToDepartment(int empno, int deptno) {
		return employeeDAO.addEmployeeToDepartment(empno, deptno);
	}
	
	public  EmployeeDTO getEmployee(int empno) {
		Employee emp = employeeDAO.getEmployee(empno);
		if(emp!=null) {
			return getEmployeeDTO(emp);
		}
		else {
			return new EmployeeDTO();
		}
		
	}
	
	public Set<EmployeeDTO> getAllEmployees(int deptno) {
		Set<Employee> emps = employeeDAO.getAllEmployees(deptno);
		Set<EmployeeDTO> empsDTO = new HashSet<EmployeeDTO>();
		for(Employee emp : emps) {
			empsDTO.add(getEmployeeDTO(emp));
		}

		return empsDTO;
	}

	
}
