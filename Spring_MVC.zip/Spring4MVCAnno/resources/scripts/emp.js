/**
 * 
 */

$(document).ready(function(){
	alert("loading..");
	$('#empno').blur(function(){
		alert("calling...");
		var empno = $('#empno').val();
		if(empno != "") {
			alert("calling...");
			$('#empnomsg').html("");
			//var data = "empno=" + empno;
			var url = "/springmvc/loadEmployee/" + empno;
			alert("calling..." + url);
			$.ajax({
				type:"GET",
				url:url,
				dataType: "xml",
				success: function(output) {
					$('#empnomsg').html("");
					$('#empname').val($(output).find("empname").text());
					$('#salary').val($(output).find("salary").text());
					$('#job').val($(output).find("job").text());
					$('#deptno').val($(output).find("deptno").text());
				},
				error:function(req, status, error) {
					console.log(status, error );
				}
			});
		}
		else{
			$('#empnomsg').html("Empno is mandatory");
		}
	});
});
