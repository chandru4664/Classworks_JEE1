package com.htc.spring4mvc.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class DepartmentDTO implements Serializable{

	private int deptno;
	private String deptname;
	
	public DepartmentDTO() {}

	public DepartmentDTO(int deptno, String deptname) {
		super();
		this.deptno = deptno;
		this.deptname = deptname;
	}

	@Override
	public String toString() {
		return "DepartmentDTO [deptno=" + deptno + ", deptname=" + deptname + "]";
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
}
