package com.htc.spring4mvc.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EmployeeDTO implements Serializable{

	private Integer empno;
	private String empname;
	private String job;
	private Double salary;
	private Integer deptno;

	public EmployeeDTO() {
		empno=0;
		empname="";
		job="";
		salary=0.0;
		deptno=0;
	}
	public EmployeeDTO(Integer empno, String empname, String job, Double salary, int deptno) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.job = job;
		this.salary = salary;
		this.deptno = deptno;
	}
	public Integer getEmpno() {
		return empno;
	}
	public void setEmpno(Integer empno) {
		this.empno = empno;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

}
