package com.htc.spring4mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.htc.spring4mvc.dto.DepartmentDTO;
import com.htc.spring4mvc.dto.EmployeeDTO;
import com.htc.spring4mvc.service.EmployeeService;
import com.htc.spring4mvc.validator.DepartmentValidator;

@Controller
public class DepartmentController {

	EmployeeService employeeService;
	DepartmentValidator departmentValidator;
	
	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@Autowired
	public void setDepartmentValidator(DepartmentValidator departmentValidator) {
		this.departmentValidator = departmentValidator;
	}

	@InitBinder
	public void dataBinder(WebDataBinder binder) {		
		binder.addValidators(departmentValidator);
	}

	//Homepage loading..
	@RequestMapping(method=RequestMethod.GET)
	public String index() {
		return "index";
	}

	@RequestMapping(method=RequestMethod.GET, value="/addDeptForm")
	public ModelAndView addDepartmentForm() {
		DepartmentDTO dept = new DepartmentDTO();
		ModelAndView mv = new ModelAndView("adddept", "dept", dept);
		return mv;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/addDept")
	public ModelAndView addDepartment(@ModelAttribute(name="dept") @Validated DepartmentDTO dept, BindingResult result) {
			String msg = "";
			
			if(result.hasErrors()) {
				ModelAndView mv = new ModelAndView("adddept", "dept", dept);
				return mv;
			}
			else {
				boolean insert = employeeService.addDepartment(dept);
				if(insert) {
					msg = "Department Added Successfully";
				}
				else {
					msg = "Deparment Entry Failed";
				}
				
				ModelAndView mv = new ModelAndView();
				mv.setViewName("adddeptsuccess");
				mv.addObject("message", msg);
				return mv;
			}
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/assignempdeptform")
	public String showDeptAssignForm() {
		return "addempdeptform";
	}

	@RequestMapping(method=RequestMethod.POST,value="/addemptodept")
	public ModelAndView addemployeetodept(@RequestParam(name="empno") int empno, @RequestParam(name="deptno") int deptno) {
		String msg = "";
		boolean result = employeeService.addEmployeeToDepartment(empno, deptno);
		if(result) {
			msg = "Employee assigned to Department";
		}
		else {
			msg = "Operation Failed";
		}
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addemptodeptsuccess");
		mv.addObject("message", msg);
		return mv;		
	}

	
	
	@RequestMapping(method=RequestMethod.GET, value="showAllDept")
	public ModelAndView getAllDept() {
		
		List<DepartmentDTO> deptList = new ArrayList<DepartmentDTO>();
		deptList.add(new DepartmentDTO(10,"Accounts"));
		deptList.add(new DepartmentDTO(20,"Admin"));
		deptList.add(new DepartmentDTO(30,"Sales"));
		deptList.add(new DepartmentDTO(40,"Purchases"));
		
		ModelAndView mv = new ModelAndView("listdepts", "deptList", deptList);
		return mv;
	}
	

	@ExceptionHandler(Exception.class)
	public ModelAndView exceptionHandler(Exception ex) {
		ModelAndView mv = new ModelAndView("error", "errMsg", ex.toString());
		return mv;
	}
}
