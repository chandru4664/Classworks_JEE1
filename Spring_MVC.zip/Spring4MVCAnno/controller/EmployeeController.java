package com.htc.spring4mvc.controller;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.htc.spring4mvc.dto.EmployeeDTO;
import com.htc.spring4mvc.service.EmployeeService;

@Controller
public class EmployeeController {

	EmployeeService employeeService;
	
	@Autowired
	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/editEmployee")
	public ModelAndView editEmployeeScreen() {
		EmployeeDTO empDTO = new EmployeeDTO();
		return new ModelAndView("editemp", "emp", empDTO);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/loadEmployee/{empno}", produces=MediaType.APPLICATION_XML_VALUE)
	@ResponseBody  // Write the output directly to response.
	public EmployeeDTO getEmployeeXML(@PathVariable("empno") Integer empno) {
		EmployeeDTO empDTO = employeeService.getEmployee(empno);
		return empDTO;
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView exceptionHandler(Exception ex) {
		ModelAndView mv = new ModelAndView("error", "errMsg", ex.toString());
		return mv;
	}


}
