package com.htc.spring4mvc.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="HTC_EMPLOYEE")
@SequenceGenerator(name="empno_seq",sequenceName="HTCEMPNO_SEQ")
@NamedQueries(value= {
        @NamedQuery(name="findByJob", query="select e from Employee e where e.job=:job"),
        @NamedQuery(name="findById", query="select e from Employee e where e.empno=:eno")
	})
public class Employee {
	
	private Integer empno;
	private String empname;
	private Double salary;	
	private String job;
	
	Department department; 
	
	public Employee() {
		department = new Department();
		
	}
	
	public Employee(Integer empno, String empname, Double salary, String job) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.salary = salary;
		this.job = job;
	}

	public Employee(String empname, Double salary, String job) {
		super();
		this.empname = empname;
		this.salary = salary;
		this.job = job;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="empno_seq")
	@Column(name="EMPNO")
	public Integer getEmpno() {
		return empno;
	}

	public void setEmpno(Integer empno) {
		this.empno = empno;
	}

	@Column
	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}
	@Column
	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	@Column
	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empname=" + empname + ", salary=" + salary + ", job=" + job
				+ ", department=" + department + "]";
	}
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="DEPTNO")
	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
}
