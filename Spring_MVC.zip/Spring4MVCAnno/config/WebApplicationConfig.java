package com.htc.spring4mvc.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration	
@EnableWebMvc
@EnableAspectJAutoProxy
@EnableTransactionManagement
@ComponentScan(basePackages={"com.htc.spring4mvc.controller","com.htc.spring4mvc.service","com.htc.spring4mvc.dao","com.htc.spring4mvc.validator"})
public class WebApplicationConfig extends WebMvcConfigurerAdapter{

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// TODO Auto-generated method stub
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	@Bean
	public InternalResourceViewResolver getInternalResourceViewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setViewClass(JstlView.class);
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}

	@Bean(name="dataSource")
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@172.16.50.20:1521:orcl11g");
		dataSource.setUsername("trng11g");
		dataSource.setPassword("trng$11g");
		return dataSource;
	}
	
	@Bean(name="hibernateJpaVendorAdapter")
	public HibernateJpaVendorAdapter getHibernateJpavendorAdapter() {
		return new HibernateJpaVendorAdapter();
	}
	
	@Bean(name="emf")
	public LocalContainerEntityManagerFactoryBean getEntityManagerFactory() {
		LocalContainerEntityManagerFactoryBean emf= new LocalContainerEntityManagerFactoryBean();
		emf.setDataSource(getDataSource());
		emf.setJpaVendorAdapter(getHibernateJpavendorAdapter());
		emf.setPackagesToScan("com.htc.spring4mvc.entity");
		Properties props = new Properties();
		props.put("hibernate.dialect","org.hibernate.dialect.Oracle10gDialect");
		emf.setJpaProperties(props);
		return emf;
	}
	
	@Bean(name="transactionManager")
	public JpaTransactionManager getTransactionManager() {
		JpaTransactionManager tr = new JpaTransactionManager();
		tr.setEntityManagerFactory(getEntityManagerFactory().getObject());
		return tr;
	}
	
}
