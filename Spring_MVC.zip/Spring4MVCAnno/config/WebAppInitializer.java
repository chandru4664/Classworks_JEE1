package com.htc.spring4mvc.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

// To start your servlet container. and load & register DispatcherServlet in it.
// Also Prepare a WebApplicationContext and add to DispatcherServlet. 

public class WebAppInitializer implements WebApplicationInitializer{

	@Override
	public void onStartup(ServletContext context) throws ServletException {
		// TODO Auto-generated method stub
		
		System.out.println("Loading...");
		AnnotationConfigWebApplicationContext webApplicationContext = new AnnotationConfigWebApplicationContext();
		webApplicationContext.setServletContext(context);
		webApplicationContext.register(WebApplicationConfig.class);
		
		ServletRegistration.Dynamic servlet = context.addServlet("dispatcherServlet", new DispatcherServlet(webApplicationContext));
		servlet.addMapping("/");
		servlet.addMapping("/resources");
	}
}
