package com.htc.spring4mvc.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.htc.spring4mvc.dto.DepartmentDTO;

@Component
public class DepartmentValidator implements Validator{

	@Override
	public boolean supports(Class<?> cls) {
		return DepartmentDTO.class.equals(cls);	
	}

	@Override
	public void validate(Object target, Errors errors) {
		DepartmentDTO dept = (DepartmentDTO)target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "deptno", "required", "Deptno is mandatory");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "deptname", "required", "Deptname is mandatory");
		
		if(dept.getDeptno() == 0) {
			errors.rejectValue("deptno","","Invalid Deptno");
		}
	}
}
