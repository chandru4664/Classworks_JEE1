package com.htc.spring4mvc.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.htc.spring4mvc.dao.EmployeeDAO;
import com.htc.spring4mvc.dto.DepartmentDTO;
import com.htc.spring4mvc.entity.Department;
import com.htc.spring4mvc.entity.Employee;

@Service("employeeService")
@Transactional(propagation=Propagation.REQUIRED, readOnly=true)
public class EmployeeService {

	public DepartmentDTO getDepartmentDTO(Department dept) {
		return new DepartmentDTO(dept.getDeptno(), dept.getDeptName());
	}
	
	public Department getDepartment(DepartmentDTO dept) {
		return new Department(dept.getDeptno(), dept.getDeptname());
	}
	
	EmployeeDAO employeeDAO;
	@Autowired
	public EmployeeService(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public boolean addEmployee( Employee emp) {
		return employeeDAO.addEmployee(emp);
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public boolean addDepartment(DepartmentDTO dept) {
		
		return employeeDAO.addDepartment(getDepartment(dept));
	}
	
	@Transactional(rollbackFor=java.lang.Exception.class, readOnly=false)
	public  boolean addEmployeeToDepartment(int empno, int deptno) {
		return employeeDAO.addEmployeeToDepartment(empno, deptno);
	}
	
	public  Employee getEmployee(int empno) {
		return employeeDAO.getEmployee(empno);
		
	}
	public Set<Employee> getAllEmployees(int deptno) {
		return employeeDAO.getAllEmployees(deptno);
	}

}
