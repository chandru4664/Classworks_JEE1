package com.htc.spring4mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class WelcomeController {

	
	@RequestMapping(method=RequestMethod.GET, value="/greetUser")
	//@GetMapping("/greetUser")
	public String greetUser() {
		return "greet";  //control string.
	}

	
	@RequestMapping(method=RequestMethod.GET, value="/printdata")
	public ModelAndView printData() {
		
		//contact model component..
		
		ModelAndView mv = new ModelAndView("printdata","data","Some Data");
		return mv;  
	}
	
}
