package com.htc.spring4mvc.utils;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(Exception.class)
	public ModelAndView exceptionHandler(Exception ex) {
		ModelAndView mv = new ModelAndView("error", "errMsg", ex.toString());
		return mv;
	}

}
