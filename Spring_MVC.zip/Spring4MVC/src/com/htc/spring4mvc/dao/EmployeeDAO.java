package com.htc.spring4mvc.dao;

import java.util.Set;

import com.htc.spring4mvc.dto.DepartmentDTO;
import com.htc.spring4mvc.entity.Department;
import com.htc.spring4mvc.entity.Employee;

public interface EmployeeDAO {

	public boolean addEmployee( Employee emp) ;
	public boolean addDepartment(Department dept);
	public  boolean addEmployeeToDepartment(int empno, int deptno);
	public  Employee getEmployee(int empno);
	public Set<Employee> getAllEmployees(int deptno);
}
