package com.htc.spring4mvc.dao;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.htc.spring4mvc.dto.DepartmentDTO;
import com.htc.spring4mvc.entity.Department;
import com.htc.spring4mvc.entity.Employee;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public boolean addEmployee(Employee emp) {
		boolean insert = false;
		try {
			em.persist(emp);
			insert =true;
		}
		catch(Exception ex) {
			throw ex;
		}
		return insert;

	}


	@Override
	public boolean addDepartment(Department dept) {
		boolean insert = false;
		try {
			em.persist(dept);
			insert =true;
		}
		catch(Exception ex) {
			throw ex;
		}
		return insert;
	}


	@Override
	public boolean addEmployeeToDepartment(int empno, int deptno) {
		boolean insert = false;
		Department dept = em.find(Department.class, deptno);
		Employee emp = em.find(Employee.class, empno);
		
		if(dept !=null && emp!=null) {
			dept.getEmployees().add(emp);
			emp.setDepartment(dept);
			insert = true;
		}
		else {
			throw new RuntimeException();
		}
		return insert;
	}

	@Override
	public Employee getEmployee(int empno) {

		return em.find(Employee.class, empno);

	}

	@Override
	public Set<Employee> getAllEmployees(int deptno) {

		Department dept = em.find(Department.class, deptno);
		Set<Employee> emps = dept.getEmployees();
		return emps;
	}
}
