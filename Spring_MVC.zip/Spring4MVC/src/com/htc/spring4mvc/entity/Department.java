package com.htc.spring4mvc.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="HTC_DEPT")
public class Department {

	@Id
	@Column
	private Integer deptno;
	@Column
	private String deptName;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="DEPTNO")
	Set<Employee> employees;
	
	public Department() {
		employees = new HashSet<Employee>();
	}

	public Department(Integer deptno, String deptName) {
		super();
		this.deptno = deptno;
		this.deptName = deptName;
	}

	public Integer getDeptno() {
		return deptno;
	}

	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	@Override
	public String toString() {
		return "Department [deptno=" + deptno + ", deptName=" + deptName + "]";
	}

	public Set<Employee> getEmployees() {
		if(employees == null)
			return new HashSet<Employee>();
		return employees;
	}

	public void setEmployees(HashSet<Employee> employees) {
		this.employees = employees;
	}
	
}
