package com.htc.rest;
import java.io.File;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
 
@Path("/files")
public class FileDownloadService {
 	private static final String FILE_PATH = "D:\\AP Training\\Day1.txt";
 	private static final String IMAGE_PATH = "C:\\Users\\Public\\Pictures\\Sample Pictures\\Jellyfish.jpg";
 	private static final String PDF_PATH ="D:\\AP Training\\SeleniumAPTeam.pdf";
	
 	@GET
	@Path("/txt")
	@Produces("text/plain")
	public Response getFile() {
 
		File file = new File(FILE_PATH);
 
		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition","attachment; filename=\"Day1.txt\"");
		return response.build();
 
	}

 	@GET
	@Path("/image")
	@Produces("image/jpg")
	public Response getImage() {
 
		File file = new File(IMAGE_PATH);
 
		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition","attachment; filename=\"Jellyfish.jpg\"");
		return response.build();
 
	}

 	@GET
	@Path("/pdf")
	@Produces("application/pdf")
	public Response getPdf() {
 
		File file = new File(PDF_PATH);
 
		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition","attachment; filename=\"SeleniumAPTeam.pdf\"");
		return response.build();
 
	}

}