package com.htc.model;

import com.htc.empservice.MyWebservice;
import com.htc.empservice.WebServiceImplService;




public class AccessService {

	public MyWebservice getService(){
		
		WebServiceImplService service = new WebServiceImplService();
		MyWebservice   ws = service.getWebServiceImplPort();
		return ws;
	}
}
