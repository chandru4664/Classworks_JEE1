@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.htc.com/")
package com.htc.empservice;
