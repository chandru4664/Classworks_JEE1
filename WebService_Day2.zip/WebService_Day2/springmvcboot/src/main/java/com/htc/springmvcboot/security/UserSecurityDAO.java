package com.htc.springmvcboot.security;

public interface UserSecurityDAO {

	public UserInfo findByssoId(String ssoId);
}
