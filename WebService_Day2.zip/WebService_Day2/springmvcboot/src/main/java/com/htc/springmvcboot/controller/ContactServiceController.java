package com.htc.springmvcboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.htc.springmvcboot.model.ContactInfo;

@Controller
public class ContactServiceController {

	@RequestMapping("/findContact/{contactId}")
	public ModelAndView findContactById(@PathVariable("contactId")String contactId) {
		
		RestTemplate restTemplate = new RestTemplate();
		
		String url="http://localhost:8080/jerseydemo/rest/contactService/findContactByIdJSON?contactId="+ contactId;
		ContactInfo response = restTemplate.getForObject(url, ContactInfo.class);
		
		ModelAndView mv = new ModelAndView("contact", "contact", response);
		return mv;
	}
	
}
