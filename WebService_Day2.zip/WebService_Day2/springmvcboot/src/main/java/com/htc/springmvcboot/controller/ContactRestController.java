package com.htc.springmvcboot.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.htc.jaxrs.resource.dao.ContactDAO;
import com.htc.jaxrs.resource.dao.ContactDAOImpl;
import com.htc.springmvcboot.model.ContactInfo;

@RestController
public class ContactRestController {

	@RequestMapping(value="/findContactById/{contactId}", method=RequestMethod.GET, produces=MediaType.APPLICATION_XML_VALUE)
	//@ResponseBody
	
	public ContactInfo findContactById(@PathVariable("contactId") String contactId) {
		ContactDAO dao = new ContactDAOImpl();
		ContactInfo contact = dao.findContactById(contactId);
		return contact;
	}
	
	
	
}
