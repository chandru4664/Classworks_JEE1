package com.htc.jaxrs.resource.dao;

import java.util.ArrayList;

import com.htc.springmvcboot.model.ContactInfo;

public interface ContactDAO {

	public ContactInfo findContactById(String contactId);
	public ArrayList<ContactInfo> findContactByOrganization(String organization);
}
 