package com.htc.ws;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jws.WebService;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.htc.model.Employee;

@WebService(endpointInterface="com.htc.ws.MyWebservice")
public class WebServiceImpl implements MyWebservice{

	
	public Employee getEmployee(int eid) 
	{
		Employee e=null;
		Connection con = null;
		try
		{
			InitialContext ctx=new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/db");
			 con=ds.getConnection();
			 
			PreparedStatement ps=con.prepareStatement("select empno,ename,sal,job from emp where empno=?");
			ps.setInt(1, eid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt(1);
				String ename=rs.getString(2);
				double salary=rs.getDouble(3);
				
				String job=rs.getString(4);
				 e=new Employee(id,ename,salary,job);
			}
			
			
		}
		catch(SQLException se )
		{
			se.printStackTrace();
		} catch (NamingException ee) {
			// TODO Auto-generated catch block
			ee.printStackTrace();
		}
	
		
		
		return e;
		
	}
	
	
	
	
	

}
