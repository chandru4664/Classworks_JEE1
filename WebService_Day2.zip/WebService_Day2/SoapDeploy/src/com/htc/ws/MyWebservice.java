package com.htc.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.htc.model.Employee;

@WebService
public interface MyWebservice {
	
	@WebMethod
	public Employee getEmployee(int eid) ;

	
}
