﻿
drop table contactinfo
create table ContactInfo(contactId char(20) primary key, contactName char(30), organization char(30), address char(30), landlineno char(15), mobileno char(15), emailid char(30));

select * from contactinfo

insert into contactinfo values('C123', 'Charles','HTC','Chennai','23423423','923923823','charles@htcindia.com');
insert into contactinfo values('C124', 'Gopi','HTC','Chennai','23423423','9876676733','Gopi@htcindia.com')
