package com.htc.hibernate.relations.manytomany;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="employees")
public class Employees {
	@Id
	private int empId;
	@Column(length=30)
	private String empName;
	@Temporal(TemporalType.DATE)
	private Date hireDate;
	@Column
	private double salary;
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name="emp_skills",
			   joinColumns=@JoinColumn(name="emp_Id",referencedColumnName="empId"),
			   inverseJoinColumns=@JoinColumn(name="skill_Id",referencedColumnName="skillId"))
	private Set<Skills> skills=new HashSet<Skills>();
	
	public Employees(int empId, String empName, Date hireDate, double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.hireDate = hireDate;
		this.salary = salary;
	}
	public Employees(int empId, String empName, Date hireDate, double salary, Set<Skills> skills) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.hireDate = hireDate;
		this.salary = salary;
		this.skills = skills;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public Employees() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employees(int empId, String empName, double salary,
			Set<Skills> skills) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.skills = skills;
	}
	public Employees(int empId, String empName, double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		
	}
	@Override
	public String toString() {
		return "Employees [empId=" + empId + ", empName=" + empName + ", hireDate=" + hireDate + ", salary=" + salary
				+ ", skills=" + skills + "]";
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Set<Skills> getSkills() {
		return skills;
	}
	public void setSkills(Set<Skills> skills) {
		this.skills = skills;
	}
	
	

}
