package com.htc.hibernate.relations.onetomany;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="players")
public class Players implements Serializable{
	
	@Id
	private int playerId;
	
	@Column(length=30)
	private String playerName;
	
	@Column(length=30)
	private String role;
	
	public Players() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Players(int playerId, String playerName, String role) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.role = role;
	}
	@Override
	public String toString() {
		return "Players [playerId=" + playerId + ", playerName=" + playerName
				+ ", role=" + role + "]";
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	

}
