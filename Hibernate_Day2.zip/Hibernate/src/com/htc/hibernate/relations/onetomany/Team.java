package com.htc.hibernate.relations.onetomany;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="team")
public class Team implements Serializable {
	@Id
	private int teamId;
	@Column(length=30)
	private String teamName;
	@Column(length=30)
	private String trainer;
	
	@OneToMany(fetch=FetchType.EAGER)
	@JoinColumn(name="teamId")
	private Set<Players> players=new HashSet<Players>();
	
	@Override
	public String toString() {
		return "Team [teamId=" + teamId + ", teamName=" + teamName
				+ ", trainer=" + trainer + ", players=" + players + "]";
	}
	public Team(int teamId, String teamName, String trainer,
			Set<Players> players) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		this.trainer = trainer;
		this.players = players;
	}
	public Team() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTeamId() {
		return teamId;
	}
	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getTrainer() {
		return trainer;
	}
	public void setTrainer(String trainer) {
		this.trainer = trainer;
	}
	public Set<Players> getPlayers() {
		return players;
	}
	public void setPlayers(Set<Players> players) {
		this.players = players;
	};
	
	
}
