package com.htc.hibernate.relations.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="keyboard")
public class Keyboard {
	@Id
	private int serialNo;
	@Column(length=30)
	private String manufacturer;
	@Column(length=30)
	private String language;
	//for bi-directional relationship
	/*@OneToOne(mappedBy="keyboard")
	private Mobile mobile;*/
	public Keyboard() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Keyboard(int serialNo, String manufacturer, String language) {
		super();
		this.serialNo = serialNo;
		this.manufacturer = manufacturer;
		this.language = language;
	}
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	@Override
	public String toString() {
		return "Keyboard [serialNo=" + serialNo + ", manufacturer="
				+ manufacturer + ", language=" + language + "]";
	}
	
	
}
