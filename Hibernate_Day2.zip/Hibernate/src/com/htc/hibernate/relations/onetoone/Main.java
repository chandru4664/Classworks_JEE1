package com.htc.hibernate.relations.onetoone;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class Main {

	static SessionFactory sf=null;
	static{
		// Hibernate config 4.3
		Configuration cf=new Configuration();
		cf=cf.configure();
		cf.addAnnotatedClass(com.htc.hibernate.relations.onetoone.Mobile.class);
		cf.addAnnotatedClass(com.htc.hibernate.relations.onetoone.Keyboard.class);
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		builder=builder.applySettings(cf.getProperties());
		ServiceRegistry registry=builder.build();
		sf=cf.buildSessionFactory(registry);
	}
	public static void main(String[] args) {
		Session session=sf.openSession();
		Transaction trans=session.getTransaction();
		trans.begin();
		try{
			Keyboard keyboard=new Keyboard(1,"Samsung","English");
			session.save(keyboard);
			
			session.save(new Mobile(1,"Samsung","Mx100",keyboard));
			trans.commit();
			System.out.println("Mobile Data is saved...");
		}catch(HibernateException he){
			he.printStackTrace();
			trans.rollback();
		}
		
	}
}
