package com.htc.hibernate.simple;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class Main {

	static SessionFactory sessionFactory=null;
	
	// Hibernate 5.3 configuration
	/*static{
		Configuration config=new Configuration();
		config.configure();
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		builder.applySettings(config.getProperties());
		StandardServiceRegistry standardServiceRegistry=builder.build();
		MetadataSources metadataSources=new MetadataSources(standardServiceRegistry);
		//metadataSources.addAnnotatedClass(Cyclone.class);
		Metadata metadata=metadataSources.buildMetadata();
		sessionFactory=metadata.buildSessionFactory();
	}*/
	
	// Hibernate 4.9 configuration
	static{
		Configuration cf=new Configuration();
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder();
		cf=cf.configure();
		cf.addAnnotatedClass(Cyclone.class);
		builder=builder.applySettings(cf.getProperties());
		ServiceRegistry registry=builder.build();
		sessionFactory=cf.buildSessionFactory(registry);
		
	}

	public static void main(String[] args) {
		Session session=sessionFactory.openSession();
		Transaction tran=session.getTransaction();
		
		try{
			tran.begin();
			Cyclone vardah=new Cyclone(127,"Nada",100.00,"chennai",500000.00);
			// Insert
			session.save(vardah);
			
			// retrive
			//vardah=(Cyclone)session.load(Cyclone.class, 125);
			//System.out.println(vardah.toString());
			
			
			// Delete
			//session.delete(session.load(Cyclone.class,123));
			//System.out.println("Object deleted...");
			
			// update
			/*vardah=(Cyclone)session.load(Cyclone.class, 124);
			vardah.setSpeed(160.00);
			vardah.setAffectedLocation("Nellore");
			session.merge(vardah);
			System.out.println("Data updated...");
			*/
			/*vardah=new Cyclone(128,"Java",10.00,"HTC",5000.00);
			session.update(vardah);
			System.out.println("Data is updated..");*/
			tran.commit();
		}
		catch(HibernateException he){
			tran.rollback();
			he.printStackTrace();
		}
		
		
	}
	
}
