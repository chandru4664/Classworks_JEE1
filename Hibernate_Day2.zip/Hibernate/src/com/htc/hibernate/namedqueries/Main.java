package com.htc.hibernate.namedqueries;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("persist");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		try{
			/*manager.persist(new Computer(123,"Samsung"));
			manager.persist(new Computer(124,"HP"));
			manager.persist(new Computer(125,"DEll"));
			manager.persist(new Computer(126,"Lenovo"));*/
			
			//System.out.println(manager.find(Computer.class, 124));
			//Simple JPA Query
			
			/*Query qry=manager.createQuery("select c from Computer c");
			
			List<Computer> comp=qry.getResultList();
			for(Computer com:comp){
				System.out.println(com);
			}*/
			
			//Query with Positional parameter
			/*Query qry=manager.createQuery("select c from Computer c where c.compId=?1");
			qry.setParameter(1, 123);
			List<Computer> comp=qry.getResultList();
			for(Computer com:comp){
				System.out.println(com);
			}*/
			//Query with named parameter
			/*Query qry=manager.createQuery("select c from Computer c where c.compId=:id");
			qry.setParameter("id", 124);
			List<Computer> comp=qry.getResultList();
			for(Computer com:comp){
				System.out.println(com);
			}*/

			//Named Queries
			Query qry=manager.createNamedQuery("compCount");
			//qry.setParameter("comId", 125);
			Query query=manager.createNamedQuery("selectAll");
			List<Computer> comp=query.getResultList();
			for(Computer com:comp){
				System.out.println(com);
			}
			
			System.out.println("Total Number of Systems: "+qry.getSingleResult());	
			
			trans.commit();
			
		}catch(Exception e){
			e.printStackTrace();
			trans.rollback();
		}
	}
}
