package com.htc.hibernate.namedqueries;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
//@NamedQuery(name="selectById", query="select c from Computer c where c.compId=:comId")
//@NamedQuery(name="selectAll", query="select c from Computer c")
//@NamedQuery(name="compCount", query="select count(c) from Computer c")

@NamedQueries(value={@NamedQuery(name="selectById", query="select c from Computer c where c.compId=:comId"),
					@NamedQuery(name="selectAll", query="select c from Computer c"),
					@NamedQuery(name="compCount", query="select count(c) from Computer c")})
					
public class Computer implements Serializable{
	
	@Id 
	private int compId;
	@Column(length=40)
	private String manufacturer;
	public Computer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Computer(int compId, String manufacturer) {
		super();
		this.compId = compId;
		this.manufacturer = manufacturer;
	}
	@Override
	public String toString() {
		return "Computer [compId=" + compId + ", manufacturer=" + manufacturer
				+ "]";
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	
	

}
