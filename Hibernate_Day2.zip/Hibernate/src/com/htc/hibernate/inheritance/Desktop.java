package com.htc.hibernate.inheritance;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
//@DiscriminatorValue(value="Desktop")
public class Desktop extends Computers{
	@Column
	private String monitor;
	@Column
	private String cabinat;
	
	public Desktop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Desktop(int compId, String manufacturer) {
		super(compId, manufacturer);
		// TODO Auto-generated constructor stub
	}
	public Desktop(int compId, String manufacturer, String monitor, String cabinat) {
		super(compId, manufacturer);
		this.monitor = monitor;
		this.cabinat = cabinat;
	}
	@Override
	public String toString() {
		return "Desktop [monitor=" + monitor + ", cabinat=" + cabinat + "]";
	}
	public String getMonitor() {
		return monitor;
	}
	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}
	public String getCabinat() {
		return cabinat;
	}
	public void setCabinat(String cabinat) {
		this.cabinat = cabinat;
	}
	

}
