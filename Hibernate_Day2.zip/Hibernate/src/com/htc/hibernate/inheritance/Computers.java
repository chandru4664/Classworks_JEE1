package com.htc.hibernate.inheritance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity

@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
//@DiscriminatorColumn(name="Type",discriminatorType=DiscriminatorType.STRING)
public class Computers implements Serializable{
	
	@Id 
	private int compId;
	@Column(length=40)
	private String manufacturer;
	
	public Computers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Computers(int compId, String manufacturer) {
		super();
		this.compId = compId;
		this.manufacturer = manufacturer;
	}
	@Override
	public String toString() {
		return "Computer [compId=" + compId + ", manufacturer=" + manufacturer
				+ "]";
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	
	

}
