package com.htc.hibernate.inheritance;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
//@DiscriminatorValue(value="Laptop")
public class Laptop extends Computers{
	@Column
	private String processor;
	@Column
	private String speed;
	
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Laptop(String processor, String speed) {
		super();
		this.processor = processor;
		this.speed = speed;
	}

	public Laptop(int compId, String manufacturer,String processor,String speed) {
		super(compId, manufacturer);
		this.processor=processor;
		this.speed=speed;
		// TODO Auto-generated constructor stub
	}
	public String getProcessor() {
		return processor;
	}
	public void setProcessor(String processor) {
		this.processor = processor;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	@Override
	public String toString() {
		return "Laptop [processor=" + processor + ", speed=" + speed + "]";
	}
	
	

}
