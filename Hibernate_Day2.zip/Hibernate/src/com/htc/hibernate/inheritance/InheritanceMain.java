package com.htc.hibernate.inheritance;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class InheritanceMain {
	
	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("persist");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		try{
			manager.persist(new Laptop(121,"Dell","i5","250"));
			manager.persist(new Desktop(122,"V4","Samsung","Zebronics"));
			System.out.println("Data Saved successfully");
			
			//System.out.println(manager.find(Laptop.class,new Integer(121)));
			trans.commit();
		}
		catch(Exception e){
			e.printStackTrace();
			trans.rollback();
		}
	}

}
