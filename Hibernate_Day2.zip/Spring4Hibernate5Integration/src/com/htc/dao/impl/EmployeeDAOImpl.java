package com.htc.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.htc.dao.EmployeeDAO;
import com.htc.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	@Override
	public void createEmployee(Employee employee) {
		
		// try with resources block
		try(Session session = getSessionFactory().openSession()) {
			session.beginTransaction();
			session.save(employee);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		Employee employee = null;
		try(Session session = getSessionFactory().openSession()) {
			
			// normal load from DB
			//employee=session.load(Employee.class, employeeId); 
			
			// load the data from hibernate cache
			employee = session.get(Employee.class, employeeId);
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployeesDetails() {
		List<Employee>  employees = null;
		try(Session session = getSessionFactory().openSession()) {
			Query<Employee> query = session.createQuery("FROM Employee");
			employees = query.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return employees;
	}
}
