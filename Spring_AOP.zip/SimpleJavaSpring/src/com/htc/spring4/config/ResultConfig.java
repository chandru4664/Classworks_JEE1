package com.htc.spring4.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.htc.spring4.dao.ResultDAOImpl;

@Configuration
public class ResultConfig {

	@Bean(name="dataSource")
	public DataSource getDataSource(){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://localhost:5432/postgres");
		dataSource.setPassword("123Welcome");
		dataSource.setUsername("postgres");
		return dataSource;
	}
	
	@Bean(name="dao")
	public ResultDAOImpl getResultDAOImpl(){
		ResultDAOImpl dao = new ResultDAOImpl();
		dao.setDataSource(getDataSource());
		return dao;
	}
}
