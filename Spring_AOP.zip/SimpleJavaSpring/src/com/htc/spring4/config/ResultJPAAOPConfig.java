package com.htc.spring4.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.htc.spring4.aspect.LoggingAnnoAspect;
import com.htc.spring4.dao.ResultDAOJPAImpl;

@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
public class ResultJPAAOPConfig {
	
	@Bean(name="loggingAspect")
	public LoggingAnnoAspect getLoggingAspect() {
		LoggingAnnoAspect loggingAspect = new LoggingAnnoAspect();
		return loggingAspect;
	}

	@Bean(name="entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean getEntityManagerFactory(){
		LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
		entityManagerFactory.setDataSource(getDataSource());
		entityManagerFactory.setPersistenceProviderClass(HibernatePersistenceProvider.class);
		entityManagerFactory.setJpaPropertyMap(getJPAProperties());
		entityManagerFactory.setPersistenceUnitName("mydb");
		entityManagerFactory.setPackagesToScan("com.htc.spring4.beans");
		return entityManagerFactory;
	}

	
	public Map<String,String> getJPAProperties() {
		HashMap<String, String> jpaProperties = new HashMap<String,String>();
		jpaProperties.put("hibernate.dialect","org.hibernate.dialect.PostgreSQL9Dialect");
		return jpaProperties;
	}

	@Bean(name="transactionManager")
	@Autowired
	public JpaTransactionManager getTransactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(getEntityManagerFactory().getObject());
		return transactionManager;
	}
	
	@Bean(name="dataSource")
	public DataSource getDataSource(){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://localhost:5432/postgres");
		dataSource.setPassword("123Welcome");
		dataSource.setUsername("postgres");
		return dataSource;
	}
	
	@Bean(name="dao")
	public ResultDAOJPAImpl getResultDAOJPAImpl(){
		ResultDAOJPAImpl dao = new ResultDAOJPAImpl();
		return dao;
	}
}
