package com.htc.spring4.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.htc.spring4.beans.Address;
import com.htc.spring4.beans.College;
import com.htc.spring4.beans.Student;

@Configuration
public class StudentConfig {
	
	@Bean(name="address")
	public Address getAddress(){
		Address address = new Address();
		address.setDoorno("45/55/66");
		address.setStreet("Raja Street");
		address.setCity("Cennai");
		address.setPincode("645666");
		return address;
	}
	@Bean(name="college")
	public College getCollege(){
		College college = new College();
		college.setCollegeName("Some College");
		college.setCollegeAddress("Chennai");
		return college;
	}
	
 
	@Bean(name="Student",autowire=Autowire.BY_NAME)
	public Student getStudent(){
		Student student = new Student();
		student.setRegno("R04040");
		student.setStudentName("Goutham");
		//student.setAddress(getAddress());
		//student.setCollege(getCollege());
		return student;
	}
}
