package com.htc.spring4.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.htc.spring4.aspect.LoggingAnnoAspect;
import com.htc.spring4.dao.ResultDAOImpl;

@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
public class ResultAOPConfig {
	
	@Bean(name="loggingAspect")
	public LoggingAnnoAspect getLoggingAspect() {
		LoggingAnnoAspect loggingAspect = new LoggingAnnoAspect();
		return loggingAspect;
	}
	
	@Bean(name="transactionManager")
	public DataSourceTransactionManager getTransactionManager() {
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
		transactionManager.setDataSource(getDataSource());
		return transactionManager;
	}
	
	@Bean(name="dataSource")
	public DataSource getDataSource(){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://localhost:5432/postgres");
		dataSource.setPassword("123Welcome");
		dataSource.setUsername("postgres");
		return dataSource;
	}
	
	@Bean(name="dao")
	public ResultDAOImpl getResultDAOImpl(){
		ResultDAOImpl dao = new ResultDAOImpl();
		dao.setDataSource(getDataSource());
		return dao;
	}
}
