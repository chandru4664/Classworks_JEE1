package com.htc.spring4.aspect;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;

public class LoggingAspect implements MethodBeforeAdvice, AfterReturningAdvice{

	Log logger = LogFactory.getLog(LoggingAspect.class);

	@Override
	public void afterReturning(Object ret, Method method, Object[] args,
			Object target) throws Throwable {
		// TODO Auto-generated method stub
		logger.info("Class name:" + target.getClass().getName());
		logger.info("Method name:" + method.getName());
		logger.info("Return value:" + ret.toString());
	}

	@Override
	public void before(Method method, Object[] args, Object target)
			throws Throwable {
		// TODO Auto-generated method stub
		logger.info("Class name:" + target.getClass().getName());
		logger.info("Method name:" + method.getName());
		logger.info("Params:" + Arrays.toString(args));
		
	}
}
