package com.htc.spring4.aspect;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.ThrowsAdvice;

public class LoggingAspect2 implements ThrowsAdvice{

	Log logger = LogFactory.getLog(LoggingAspect2.class);
	public void afterThrowing(Method method, Object[] args,
			Object target, Exception ex) {
		logger.info(method.getName() +" - Throws exeption");
		logger.error(ex.toString());
	}
}
