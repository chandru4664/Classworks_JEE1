package com.htc.spring4.aspect;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAnnoAspect {

	@Before(value="execution(* com.htc.spring4.dao.*.*(..))")
	public void beforeMethodCall(JoinPoint jp) {
		Log logger = LogFactory.getLog(jp.getTarget().getClass());
		logger.info("Calling method- " + jp.getSignature().getName());
		logger.info("Params:" + Arrays.toString(jp.getArgs()));
	}
	@AfterReturning(value="execution(* com.htc.spring4.dao.*.*(..))", returning="result")
	public void afterReturingFromMethod(JoinPoint jp, Object result) {
		Log logger = LogFactory.getLog(jp.getTarget().getClass());
		logger.info("Returning method- " + jp.getSignature().getName());
		logger.info("Return value:" + result);
	}
	@AfterThrowing(value="execution(* com.htc.spring4.dao.*.*(..))", throwing="ex")
	public void afterExceptionThrowing(JoinPoint jp, Throwable ex) {
		Log logger = LogFactory.getLog(jp.getTarget().getClass());
		logger.info("Returning method- " + jp.getSignature().getName());
		logger.error("Exception Occured:" + ex.toString());
	}
}
