package com.htc.spring4.dao;

import java.util.List;

import com.htc.spring4.beans.ResultDTO;

public interface ResultDAO {

	public boolean insertResult(ResultDTO resultDTO);
	public ResultDTO getResult(String regno);
	public List<ResultDTO> getAllResults();
}
