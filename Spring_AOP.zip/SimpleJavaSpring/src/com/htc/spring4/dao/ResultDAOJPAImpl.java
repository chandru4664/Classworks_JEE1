package com.htc.spring4.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.htc.spring4.beans.ResultDTO;
import com.htc.spring4.beans.Student;


public class ResultDAOJPAImpl implements ResultDAO{

	@PersistenceContext
	EntityManager em ;
	
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean insertResult(ResultDTO resultDTO) {
		boolean status = false;
		try{	
			em.persist(resultDTO);
			status = true;
		}
		catch(Exception ex){
			//ex.printStackTrace();
			System.out.println(ex.getMessage());
		}
		return status;
	}

	@Transactional
	public ResultDTO getResult(String regno) {
		
			ResultDTO resultDTO = null;
			try{
				resultDTO = em.find(ResultDTO.class, regno);
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
			return resultDTO;
	}

	@Transactional
	public List<ResultDTO> getAllResults() {
		
		Query qry= em.createQuery("select rs from ResultDTO rs");
		List<ResultDTO> resultList= qry.getResultList();
		return resultList;
	}

	public boolean insertStudent(Student student) {
		return false;
	}
}
