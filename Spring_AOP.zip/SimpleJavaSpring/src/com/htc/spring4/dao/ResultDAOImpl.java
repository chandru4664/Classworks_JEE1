package com.htc.spring4.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.htc.spring4.beans.ResultDTO;
import com.htc.spring4.beans.Student;


public class ResultDAOImpl implements ResultDAO{

	DataSource dataSource;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean insertResult(ResultDTO resultDTO) {

		boolean status = false;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sql = "INSERT INTO RESULTS VALUES(?,?,?,?,?,?)";
		int insertCnt = jdbcTemplate.update(sql, resultDTO.getRegno(), resultDTO.getMark1(), resultDTO.getMark2(), resultDTO.getMark3(), resultDTO.getMark4(), resultDTO.getMark5());
		if(insertCnt>0)
			status = true;
		return status;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED, readOnly=true)
	public ResultDTO getResult(String regno) {
		// TODO Auto-generated method stub
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sql = "SELECT REGNO, SUB1, SUB2, SUB3, SUB4, SUB5 FROM RESULTS WHERE REGNO=?";
		ResultDTO resultDTO = jdbcTemplate.queryForObject(sql, new String[]{regno}, new RowMapper<ResultDTO>(){

			@Override
			public ResultDTO mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				// TODO Auto-generated method stub
				ResultDTO resultDTO = new ResultDTO();
				resultDTO.setRegno(rs.getString(1));
				resultDTO.setMark1(rs.getInt(2));
				resultDTO.setMark2(rs.getInt(3));
				resultDTO.setMark3(rs.getInt(4));
				resultDTO.setMark4(rs.getInt(5));
				resultDTO.setMark5(rs.getInt(6));
				return resultDTO;
			}
			
		});
		
		return resultDTO;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED,readOnly=true)
	public List<ResultDTO> getAllResults() {
		// TODO Auto-generated method stub
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sql = "SELECT REGNO, SUB1, SUB2, SUB3, SUB4, SUB5 FROM RESULTS";
		List<ResultDTO> resultList = jdbcTemplate.query(sql, new RowMapper<ResultDTO>(){

			@Override
			public ResultDTO mapRow(ResultSet rs, int rowNum)
					throws SQLException {
				// TODO Auto-generated method stub
				ResultDTO resultDTO = new ResultDTO();
				resultDTO.setRegno(rs.getString(1));
				resultDTO.setMark1(rs.getInt(2));
				resultDTO.setMark2(rs.getInt(3));
				resultDTO.setMark3(rs.getInt(4));
				resultDTO.setMark4(rs.getInt(5));
				resultDTO.setMark5(rs.getInt(6));
				return resultDTO;
			}
			
		});

		return resultList;
	}

	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=java.lang.Exception.class)
	public boolean insertStudent(Student student) {
		boolean status = false;
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		String sql1 = "INSERT INTO STUDENT VALUES(?,?,?)";
		String sql2 = "INSERT INTO ADDRESS VALUES(?,?,?,?,?,?)";
		//int insertCnt = jdbcTemplate.update(sql1,);
		//int insertCnt = jdbcTemplate.update(sql2,);
		//if(insertCnt>0)
		//	status = true;
		return status;
		
	}
}
