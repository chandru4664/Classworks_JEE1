package com.htc.spring4.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="RESULTS")
public class ResultDTO implements Serializable{

	@Id
	@Column
	private String regno;
	@Column(name="SUB1")
	private int mark1;
	@Column(name="SUB2")
	private int mark2;
	@Column(name="SUB3")
	private int mark3;
	@Column(name="SUB4")
	private int mark4;
	@Column(name="SUB5")
	private int mark5;
	
	public ResultDTO(){}

	
	public ResultDTO(String regno, int mark1, int mark2, int mark3, int mark4,
			int mark5) {
		super();
		this.regno = regno;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
		this.mark4 = mark4;
		this.mark5 = mark5;
	}


	public String getRegno() {
		return regno;
	}

	public void setRegno(String regno) {
		this.regno = regno;
	}

	public int getMark1() {
		return mark1;
	}

	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}

	public int getMark2() {
		return mark2;
	}

	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}

	public int getMark3() {
		return mark3;
	}

	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}

	public int getMark4() {
		return mark4;
	}

	public void setMark4(int mark4) {
		this.mark4 = mark4;
	}

	public int getMark5() {
		return mark5;
	}

	public void setMark5(int mark5) {
		this.mark5 = mark5;
	}


	@Override
	public String toString() {
		return "ResultDTO [regno=" + regno + ", mark1=" + mark1 + ", mark2="
				+ mark2 + ", mark3=" + mark3 + ", mark4=" + mark4 + ", mark5="
				+ mark5 + "]";
	}
		
}
