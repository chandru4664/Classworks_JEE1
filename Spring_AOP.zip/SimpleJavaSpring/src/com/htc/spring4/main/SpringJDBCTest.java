package com.htc.spring4.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.htc.spring4.beans.ResultDTO;
import com.htc.spring4.dao.ResultDAO;




public class SpringJDBCTest {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("jdbc.xml");
		ResultDAO resultDAO = (ResultDAO) context.getBean("dao");

		//boolean status =resultDAO.insertResult(new ResultDTO("R9090", 40, 40, 40, 40, 40));
		//System.out.println(status);
		
		ResultDTO resultDTO = resultDAO.getResult("R9090");
		System.out.println(resultDTO);
		System.out.println("==============");
		for(ResultDTO result : resultDAO.getAllResults()) {
			System.out.println(result);
		}
	}
}
