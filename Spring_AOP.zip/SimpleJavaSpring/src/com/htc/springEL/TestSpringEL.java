package com.htc.springEL;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;



@Configuration
@ComponentScan("com.htc.springEL")
public class TestSpringEL {

	@Bean(name = "person")
	public PersonTO getPerson() {
		PersonTO ret = new PersonTO();
		return ret;
	}

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(TestSpringEL.class);
		PersonTO person = (PersonTO) ctx.getBean("person");
		System.out.println(person);

		
	}
}
