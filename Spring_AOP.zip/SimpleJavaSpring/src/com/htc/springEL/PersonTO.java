package com.htc.springEL;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("person")
@SuppressWarnings("serial")
public class PersonTO implements java.io.Serializable {
 
  @Value("#{ T(java.lang.Math).random()* 100}")
  private  int  age;
  
  @Value("satyan kumar")
  private String name; 
  
  @Value("#{ elUtility.nameWordCapitalizer(person.name)}")
  private  String   storedName;
  
  @Value("#{systemProperties['user.language']+'_'+systemProperties['user.country']}")
  private  String   defaultLocale;
  
  public String getDefaultLocale() {
    return defaultLocale;
  }

  public void setDefaultLocale(String defaultLocale) {
    this.defaultLocale = defaultLocale;
  }

  @Value("#{ mapListSource.professions[2]}")
  private  String   occupation;
  
  @Value("#{ mapListSource.persons['Cricket']}")
   private  String favoriteStar;
  
  @Value("#{ mapListSource.cities[5]}")
  private  WorkingCity workLocation;	

  @Value("#{ T(com.htc.springEL.ELUtility).LOAN_LIMIT}") 
  private  double loanLimit;    

  @Value("#{elUtility.numField <= 80 }")
  private boolean numField80;
  
  public boolean isNumField80() {
    return numField80;
  }

  public void setNumField80(boolean numField80) {
    this.numField80 = numField80;
  }

public double getLoanLimit() {
    return loanLimit;
  }

  public void setLoanLimit(double loanLimit) {
    this.loanLimit = loanLimit;
}

public String getOccupation() {
     return occupation;
  }

  public void setOccupation(String occupation) {
    this.occupation = occupation;
  }

  public String getStoredName() {
    return storedName;
  }

  public void setStoredName(String storedName) {
    this.storedName = storedName;
  }


  public String getFavoriteStar() {
    return favoriteStar;
  }

  public void setFavoriteStar(String favoriteStar) {
    this.favoriteStar = favoriteStar;
  }

  public WorkingCity getWorkLocation() {
    return workLocation;
  }

  public void setWorkLocation(WorkingCity workLocation) {
    this.workLocation = workLocation;
  }

 
  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PersonTO() {
  } 

  @Override
  public String toString() {
   StringBuilder sb = new StringBuilder();
   sb.append("Age:"+this.age);
   sb.append(" Name:"+this.storedName); 
   sb.append(" DefaultLocale:"+this.defaultLocale);
   sb.append(" occupation:"+this.occupation);
   sb.append("\r\n Working Location\r\n");  
   sb.append(this.workLocation + "\r\n");	
     
   sb.append("\nFavorite Star\n");
   sb.append(this.favoriteStar + "\r\n");	
   sb.append("\nLoan Limit\n");
   sb.append(this.loanLimit + "\r\n");       
   sb.append("\nstmt that NumField  80 is-");
   sb.append(this.numField80 + "\r\n");         
   
   return sb.toString();	
  }
	
}