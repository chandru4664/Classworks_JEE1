package com.htc.springEL;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component("mapListSource")
@SuppressWarnings("serial")
public class MapListSource implements java.io.Serializable{
    
    List<WorkingCity> cities;
    List<String> professions;
    Map<String, String> persons;
    
    {
      cities = new ArrayList<>();
      professions = new ArrayList<>();
      persons = new HashMap<>();
      
      WorkingCity city = 
          new WorkingCity("Vijayawada", "Andhra Pradesh", "IN", 2500000L);
      cities.add(city);
      city = new WorkingCity("Chennai", "TamilNadu", "IN", 10000000L);
      cities.add(city);
      city = new WorkingCity("Madurai", "TamilNadu", "IN", 2400000L);
      cities.add(city);
      
      city = new WorkingCity("Hyderabad", "Telangana", "IN", 8500000L);
      cities.add(city);
      
      city = new WorkingCity("Kovai", "TamilNadu", "IN", 5400000L);
      cities.add(city);
      
      city = new WorkingCity("Chandigarh",  "Chandigarh", "IN", 6500000L);
      cities.add(city);
      
      city = new WorkingCity("Shimla", "Himachal Pradesh", "IN", 3200000L);
      cities.add(city);
      
      city = new WorkingCity("Jaipur", "Rajasthan", "IN", 5100000L);
      cities.add(city);
      
      city = new WorkingCity("VisakhaPatnam", "Andhra Pradesh", "IN", 5400000L);
      cities.add(city);
      
      city = new WorkingCity("Kanpur", "Uttar Pradesh", "IN", 4800000L);
      cities.add(city);
      
      city = new WorkingCity("NewYork City", "New York", "US", 24000000L);
      cities.add(city);
      
      city = new WorkingCity("San Francisco", "California", "US", 7500000L);
      cities.add(city);
      
      city = new WorkingCity("Tokyo City", "Tokyo", "JP", 47000000L);
      cities.add(city);
      
      city = new WorkingCity("Paris City", "Paris", "FR", 12836970L);
      cities.add(city);
      
      city = new WorkingCity("London", "Westminister", "UK", 13000000L);
      cities.add(city);
      
      Collections.addAll(professions, "Civil Engineer",
      "Plant Engineer", "Mechanical Engineer", "Homeopathy Doctor",
      "Sidda Doctor", "Civil Surgeon", "Medical Representative",
      "Bank Clerk", "Head Clerk", "Furniture Dealer", "Supervisor"
       );  
      
      persons.put("Cricket", "Sachin Tendulkar");
      persons.put("Tennis", "Swiss Federer");
      persons.put("TableTennis", "MA Long[China]");
      persons.put("Badminton", "Lin Dan[China]");
      persons.put("FootBall", "Brazil Pele");
      persons.put("Hockey", "Dhyan Chand");
      
    }

    public List<WorkingCity> getCities() {
        return cities;
    }

    public void setCities(List<WorkingCity> cities) {
        this.cities = cities;
    }

    public List<String> getProfessions() {
        return professions;
    }

    public void setProfessions(List<String> professions) {
        this.professions = professions;
    }

    public Map<String, String> getPersons() {
        return persons;
    }

    public void setPersons(Map<String, String> persons) {
        this.persons = persons;
    }
    
    
}