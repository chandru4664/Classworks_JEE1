package com.htc.springEL;

import org.springframework.stereotype.Component;

@Component("elUtility")
public class ELUtility {
    public static final double LOAN_LIMIT = 150000.0; 
    
    int numField = 80;
    public int getNumField() {
        return numField;
    }

    public void setNumField(int numField) {
        this.numField = numField;
    }

    public ELUtility() {
        
    }
    
    private String capitalizeWord(String word) {
        return Character.toUpperCase(word.charAt(0)) + word.substring(1);
    }
    public String nameWordCapitalizer(String given) {
        StringBuilder sb = null;
        if(given.contains(" ")) {
         String[] parts = given.split("[\\s]");
         sb = new StringBuilder("");
         for(String word : parts) {
           sb.append(this.capitalizeWord(word));
           sb.append(" ");
         }
        }
        else {
            return this.capitalizeWord(given);
        }
        return sb.toString().trim();                
    }

}
