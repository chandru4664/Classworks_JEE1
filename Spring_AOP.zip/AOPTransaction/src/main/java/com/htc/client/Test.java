package com.htc.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.htc.dao.exception.InsufficientAccountBalanceException;
import com.htc.model.Account;
import com.htc.service.BankService;
import com.htc.service.Impl.BankServiceImpl;

public class Test {

	
	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		BankService bankService = ctx.getBean("bankService", BankServiceImpl.class);
		Account fromAccount = new Account();
		fromAccount.setAccountNumber(12345L);
		
		Account toAccount = new Account();
		toAccount.setAccountNumber(12346L);
		
		try {
			bankService.transferFund(fromAccount, toAccount, 500.00);
		} catch (InsufficientAccountBalanceException e) {
			e.printStackTrace();
		}
		
		ctx.close();

	}

}
